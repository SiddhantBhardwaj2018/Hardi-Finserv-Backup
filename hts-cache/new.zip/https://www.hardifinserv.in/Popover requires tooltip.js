<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <link rel="pingback" href="https://www.hardifinserv.in/xmlrpc.php">
    <title>Page not found &#8211; Hardi Investment</title>
<meta name='robots' content='max-image-preview:large' />
	<style>img:is([sizes="auto" i], [sizes^="auto," i]) { contain-intrinsic-size: 3000px 1500px }</style>
	<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel="alternate" type="application/rss+xml" title="Hardi Investment &raquo; Feed" href="https://www.hardifinserv.in/feed/" />
<link rel="alternate" type="application/rss+xml" title="Hardi Investment &raquo; Comments Feed" href="https://www.hardifinserv.in/comments/feed/" />
<script type="text/javascript">
/* <![CDATA[ */
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.1.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.1.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/www.hardifinserv.in\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.8.1"}};
/*! This file is auto-generated */
!function(i,n){var o,s,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),r=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===r[t]})}function u(e,t,n){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\uddfa\ud83c\uddf3","\ud83c\uddfa\u200b\ud83c\uddf3")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!n(e,"\ud83d\udc26\u200d\ud83d\udd25","\ud83d\udc26\u200b\ud83d\udd25")}return!1}function f(e,t,n){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):i.createElement("canvas"),a=r.getContext("2d",{willReadFrequently:!0}),o=(a.textBaseline="top",a.font="600 32px Arial",{});return e.forEach(function(e){o[e]=t(a,e,n)}),o}function t(e){var t=i.createElement("script");t.src=e,t.defer=!0,i.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",s=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){i.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"}),a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=function(e){c(n=e.data),a.terminate(),t(n)})}catch(e){}c(n=f(s,u,p))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
/* ]]> */
</script>
<style id='wp-emoji-styles-inline-css' type='text/css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<link rel='stylesheet' id='wp-block-library-css' href='https://www.hardifinserv.in/wp-includes/css/dist/block-library/style.min.css?ver=6.8.1' type='text/css' media='all' />
<style id='classic-theme-styles-inline-css' type='text/css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<style id='global-styles-inline-css' type='text/css'>
:root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
:root :where(.wp-block-pullquote){font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='contact-form-7-css' href='https://www.hardifinserv.in/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=6.0.6' type='text/css' media='all' />
<link rel='stylesheet' id='stm-stm-css' href='https://www.hardifinserv.in/wp-content/uploads/stm_fonts/stm/stm.css?ver=1.0' type='text/css' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css' href='https://www.hardifinserv.in/wp-content/plugins/revslider/public/assets/css/rs6.css?ver=6.4.11' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
#rs-demo-id {}
</style>
<link rel='stylesheet' id='font-awesome-min-css' href='https://www.hardifinserv.in/wp-content/plugins/stm-post-type/theme-options/nuxy/metaboxes/assets/vendors/font-awesome.min.css?ver=1751873450' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap-css' href='https://www.hardifinserv.in/wp-content/themes/consulting/assets/css/bootstrap.min.css?ver=4.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='consulting-style-css' href='https://www.hardifinserv.in/wp-content/themes/consulting/style.css?ver=4.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='consulting-layout-css' href='https://www.hardifinserv.in/wp-content/themes/consulting/assets/css/layouts/layout_zurich/main.css?ver=4.0.2' type='text/css' media='all' />
<style id='consulting-layout-inline-css' type='text/css'>
.page_title{ }.mtc, .mtc_h:hover{
					color: #002e5b!important
				}.stc, .stc_h:hover{
					color: #ff636a!important
				}.ttc, .ttc_h:hover{
					color: #ff635a!important
				}.mbc, .mbc_h:hover, .stm-search .stm_widget_search button{
					background-color: #002e5b!important
				}.sbc, .sbc_h:hover{
					background-color: #ff636a!important
				}.tbc, .tbc_h:hover{
					background-color: #ff635a!important
				}.mbdc, .mbdc_h:hover{
					border-color: #002e5b!important
				}.sbdc, .sbdc_h:hover{
					border-color: #ff636a!important
				}.tbdc, .tbdc_h:hover{
					border-color: #ff635a!important
				}/*Hiding Header Buttons Icons to adjust in symmetry*/ .icon_text .icon i { display: none !important; }
</style>
<link rel='stylesheet' id='stm-skin-custom-generated-css' href='https://www.hardifinserv.in/wp-content/uploads/stm_uploads/skin-custom.css?ver=128131' type='text/css' media='all' />
<link rel='stylesheet' id='child-style-css' href='https://www.hardifinserv.in/wp-content/themes/consulting-child/style.css?ver=4.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css' href='https://www.hardifinserv.in/wp-content/themes/consulting/assets/css/font-awesome.min.css?ver=4.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='select2-css' href='https://www.hardifinserv.in/wp-content/themes/consulting/assets/css/select2.min.css?ver=4.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='header_builder-css' href='https://www.hardifinserv.in/wp-content/themes/consulting/assets/css/header_builder.css?ver=4.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='consulting-default-font-css' href='https://fonts.googleapis.com/css?family=Open+Sans%3A300%2C300italic%2Cregular%2Citalic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%7CMontserrat%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2Cregular%2Citalic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&#038;ver=4.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='consulting-theme-options-css' href='https://www.hardifinserv.in/wp-content/uploads/stm_uploads/theme_options.css?ver=4.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='consulting-global-styles-css' href='https://www.hardifinserv.in/wp-content/themes/consulting/assets/css/layouts/global_styles/main.css?ver=4.0.2' type='text/css' media='all' />
<style id='consulting-global-styles-inline-css' type='text/css'>

    
        .elementor-widget-video .eicon-play {
            border-color: #ff635a;
            background-color: #ff635a;
        }

        .elementor-widget-wp-widget-nav_menu ul li,
        .elementor-widget-wp-widget-nav_menu ul li a {
            color: #002e5b;
        }

        .elementor-widget-wp-widget-nav_menu ul li.current-cat:hover>a,
        .elementor-widget-wp-widget-nav_menu ul li.current-cat>a,
        .elementor-widget-wp-widget-nav_menu ul li.current-menu-item:hover>a,
        .elementor-widget-wp-widget-nav_menu ul li.current-menu-item>a,
        .elementor-widget-wp-widget-nav_menu ul li.current_page_item:hover>a,
        .elementor-widget-wp-widget-nav_menu ul li.current_page_item>a,
        .elementor-widget-wp-widget-nav_menu ul li:hover>a {
            border-left-color: #dd3333;
        }

        div.elementor-widget-button a.elementor-button,
        div.elementor-widget-button .elementor-button {
            background-color: #002e5b;
        }

        div.elementor-widget-button a.elementor-button:hover,
        div.elementor-widget-button .elementor-button:hover {
            background-color: #ff635a;
            color: #002e5b;
        }

        .elementor-default .elementor-text-editor ul:not(.elementor-editor-element-settings) li:before,
        .elementor-default .elementor-widget-text-editor ul:not(.elementor-editor-element-settings) li:before {
            color: #dd3333;
        }

        .consulting_elementor_wrapper .elementor-tabs .elementor-tabs-content-wrapper .elementor-tab-mobile-title,
        .consulting_elementor_wrapper .elementor-tabs .elementor-tabs-wrapper .elementor-tab-title {
            background-color: #ff635a;
        }

        .consulting_elementor_wrapper .elementor-tabs .elementor-tabs-content-wrapper .elementor-tab-mobile-title,
        .consulting_elementor_wrapper .elementor-tabs .elementor-tabs-wrapper .elementor-tab-title a {
            color: #002e5b;
        }

        .consulting_elementor_wrapper .elementor-tabs .elementor-tabs-content-wrapper .elementor-tab-mobile-title.elementor-active,
        .consulting_elementor_wrapper .elementor-tabs .elementor-tabs-wrapper .elementor-tab-title.elementor-active {
            background-color: #002e5b;
        }

        .consulting_elementor_wrapper .elementor-tabs .elementor-tabs-content-wrapper .elementor-tab-mobile-title.elementor-active,
        .consulting_elementor_wrapper .elementor-tabs .elementor-tabs-wrapper .elementor-tab-title.elementor-active a {
            color: #ff635a;
        }

        .radial-progress .circle .mask .fill {
            background-color: #ff635a;
        }

    

    
</style>
<link rel='stylesheet' id='stm_megamenu-css' href='https://www.hardifinserv.in/wp-content/themes/consulting/inc/megamenu/assets/css/megamenu.css?ver=6.8.1' type='text/css' media='all' />
<link rel='stylesheet' id='qlwapp-frontend-css' href='https://www.hardifinserv.in/wp-content/plugins/wp-whatsapp-chat/build/frontend/css/style.css?ver=7.7.1' type='text/css' media='all' />
<link rel='stylesheet' id='popup-maker-site-css' href='https://www.hardifinserv.in/wp-content/plugins/popup-maker/assets/css/pum-site.min.css?ver=1.20.5' type='text/css' media='all' />
<style id='popup-maker-site-inline-css' type='text/css'>
/* Popup Google Fonts */
@import url('//fonts.googleapis.com/css?family=Montserrat|Acme');

/* Popup Theme 4032: Floating Bar - Soft Blue */
.pum-theme-4032, .pum-theme-floating-bar { background-color: rgba( 255, 255, 255, 0.00 ) } 
.pum-theme-4032 .pum-container, .pum-theme-floating-bar .pum-container { padding: 8px; border-radius: 0px; border: 1px none #000000; box-shadow: 1px 1px 3px 0px rgba( 2, 2, 2, 0.23 ); background-color: rgba( 238, 246, 252, 1.00 ) } 
.pum-theme-4032 .pum-title, .pum-theme-floating-bar .pum-title { color: #505050; text-align: left; text-shadow: 0px 0px 0px rgba( 2, 2, 2, 0.23 ); font-family: inherit; font-weight: 400; font-size: 32px; line-height: 36px } 
.pum-theme-4032 .pum-content, .pum-theme-floating-bar .pum-content { color: #505050; font-family: inherit; font-weight: 400 } 
.pum-theme-4032 .pum-content + .pum-close, .pum-theme-floating-bar .pum-content + .pum-close { position: absolute; height: 18px; width: 18px; left: auto; right: 5px; bottom: auto; top: 50%; padding: 0px; color: #505050; font-family: Sans-Serif; font-weight: 700; font-size: 15px; line-height: 18px; border: 1px solid #505050; border-radius: 15px; box-shadow: 0px 0px 0px 0px rgba( 2, 2, 2, 0.00 ); text-shadow: 0px 0px 0px rgba( 0, 0, 0, 0.00 ); background-color: rgba( 255, 255, 255, 0.00 ); transform: translate(0, -50%) } 

/* Popup Theme 4033: Content Only - For use with page builders or block editor */
.pum-theme-4033, .pum-theme-content-only { background-color: rgba( 0, 0, 0, 0.70 ) } 
.pum-theme-4033 .pum-container, .pum-theme-content-only .pum-container { padding: 0px; border-radius: 0px; border: 1px none #000000; box-shadow: 0px 0px 0px 0px rgba( 2, 2, 2, 0.00 ) } 
.pum-theme-4033 .pum-title, .pum-theme-content-only .pum-title { color: #000000; text-align: left; text-shadow: 0px 0px 0px rgba( 2, 2, 2, 0.23 ); font-family: inherit; font-weight: 400; font-size: 32px; line-height: 36px } 
.pum-theme-4033 .pum-content, .pum-theme-content-only .pum-content { color: #8c8c8c; font-family: inherit; font-weight: 400 } 
.pum-theme-4033 .pum-content + .pum-close, .pum-theme-content-only .pum-content + .pum-close { position: absolute; height: 18px; width: 18px; left: auto; right: 7px; bottom: auto; top: 7px; padding: 0px; color: #000000; font-family: inherit; font-weight: 700; font-size: 20px; line-height: 20px; border: 1px none #ffffff; border-radius: 15px; box-shadow: 0px 0px 0px 0px rgba( 2, 2, 2, 0.00 ); text-shadow: 0px 0px 0px rgba( 0, 0, 0, 0.00 ); background-color: rgba( 255, 255, 255, 0.00 ) } 

/* Popup Theme 3946: Light Box */
.pum-theme-3946, .pum-theme-lightbox { background-color: rgba( 0, 0, 0, 0.60 ) } 
.pum-theme-3946 .pum-container, .pum-theme-lightbox .pum-container { padding: 18px; border-radius: 3px; border: 8px solid #000000; box-shadow: 0px 0px 30px 0px rgba( 2, 2, 2, 1.00 ); background-color: rgba( 255, 255, 255, 1.00 ) } 
.pum-theme-3946 .pum-title, .pum-theme-lightbox .pum-title { color: #000000; text-align: left; text-shadow: 0px 0px 0px rgba( 2, 2, 2, 0.23 ); font-family: inherit; font-size: 32px; line-height: 36px } 
.pum-theme-3946 .pum-content, .pum-theme-lightbox .pum-content { color: #000000; font-family: inherit } 
.pum-theme-3946 .pum-content + .pum-close, .pum-theme-lightbox .pum-content + .pum-close { position: absolute; height: 30px; width: 30px; left: auto; right: -24px; bottom: auto; top: -24px; padding: 0px; color: #ffffff; font-family: inherit; font-size: 24px; line-height: 26px; border: 2px solid #ffffff; border-radius: 30px; box-shadow: 0px 0px 15px 1px rgba( 2, 2, 2, 0.75 ); text-shadow: 0px 0px 0px rgba( 0, 0, 0, 0.23 ); background-color: rgba( 0, 0, 0, 1.00 ) } 

/* Popup Theme 3947: Enterprise Blue */
.pum-theme-3947, .pum-theme-enterprise-blue { background-color: rgba( 0, 0, 0, 0.70 ) } 
.pum-theme-3947 .pum-container, .pum-theme-enterprise-blue .pum-container { padding: 28px; border-radius: 5px; border: 1px none #000000; box-shadow: 0px 10px 25px 4px rgba( 2, 2, 2, 0.50 ); background-color: rgba( 255, 255, 255, 1.00 ) } 
.pum-theme-3947 .pum-title, .pum-theme-enterprise-blue .pum-title { color: #315b7c; text-align: left; text-shadow: 0px 0px 0px rgba( 2, 2, 2, 0.23 ); font-family: inherit; font-size: 34px; line-height: 36px } 
.pum-theme-3947 .pum-content, .pum-theme-enterprise-blue .pum-content { color: #2d2d2d; font-family: inherit } 
.pum-theme-3947 .pum-content + .pum-close, .pum-theme-enterprise-blue .pum-content + .pum-close { position: absolute; height: 28px; width: 28px; left: auto; right: 8px; bottom: auto; top: 8px; padding: 4px; color: #ffffff; font-family: inherit; font-size: 20px; line-height: 20px; border: 1px none #ffffff; border-radius: 42px; box-shadow: 0px 0px 0px 0px rgba( 2, 2, 2, 0.23 ); text-shadow: 0px 0px 0px rgba( 0, 0, 0, 0.23 ); background-color: rgba( 49, 91, 124, 1.00 ) } 

/* Popup Theme 3948: Hello Box */
.pum-theme-3948, .pum-theme-hello-box { background-color: rgba( 0, 0, 0, 0.75 ) } 
.pum-theme-3948 .pum-container, .pum-theme-hello-box .pum-container { padding: 30px; border-radius: 80px; border: 14px solid #81d742; box-shadow: 0px 0px 0px 0px rgba( 2, 2, 2, 0.00 ); background-color: rgba( 255, 255, 255, 1.00 ) } 
.pum-theme-3948 .pum-title, .pum-theme-hello-box .pum-title { color: #2d2d2d; text-align: left; text-shadow: 0px 0px 0px rgba( 2, 2, 2, 0.23 ); font-family: Montserrat; font-size: 32px; line-height: 36px } 
.pum-theme-3948 .pum-content, .pum-theme-hello-box .pum-content { color: #2d2d2d; font-family: inherit } 
.pum-theme-3948 .pum-content + .pum-close, .pum-theme-hello-box .pum-content + .pum-close { position: absolute; height: auto; width: auto; left: auto; right: -30px; bottom: auto; top: -30px; padding: 0px; color: #2d2d2d; font-family: inherit; font-size: 32px; line-height: 28px; border: 1px none #ffffff; border-radius: 28px; box-shadow: 0px 0px 0px 0px rgba( 2, 2, 2, 0.23 ); text-shadow: 0px 0px 0px rgba( 0, 0, 0, 0.23 ); background-color: rgba( 255, 255, 255, 1.00 ) } 

/* Popup Theme 3949: Cutting Edge */
.pum-theme-3949, .pum-theme-cutting-edge { background-color: rgba( 0, 0, 0, 0.50 ) } 
.pum-theme-3949 .pum-container, .pum-theme-cutting-edge .pum-container { padding: 18px; border-radius: 0px; border: 1px none #000000; box-shadow: 0px 10px 25px 0px rgba( 2, 2, 2, 0.50 ); background-color: rgba( 30, 115, 190, 1.00 ) } 
.pum-theme-3949 .pum-title, .pum-theme-cutting-edge .pum-title { color: #ffffff; text-align: left; text-shadow: 0px 0px 0px rgba( 2, 2, 2, 0.23 ); font-family: Sans-Serif; font-size: 26px; line-height: 28px } 
.pum-theme-3949 .pum-content, .pum-theme-cutting-edge .pum-content { color: #ffffff; font-family: inherit } 
.pum-theme-3949 .pum-content + .pum-close, .pum-theme-cutting-edge .pum-content + .pum-close { position: absolute; height: 24px; width: 24px; left: auto; right: 0px; bottom: auto; top: 0px; padding: 0px; color: #1e73be; font-family: inherit; font-size: 32px; line-height: 24px; border: 1px none #ffffff; border-radius: 0px; box-shadow: -1px 1px 1px 0px rgba( 2, 2, 2, 0.10 ); text-shadow: -1px 1px 1px rgba( 0, 0, 0, 0.10 ); background-color: rgba( 238, 238, 34, 1.00 ) } 

/* Popup Theme 3950: Framed Border */
.pum-theme-3950, .pum-theme-framed-border { background-color: rgba( 255, 255, 255, 0.50 ) } 
.pum-theme-3950 .pum-container, .pum-theme-framed-border .pum-container { padding: 18px; border-radius: 0px; border: 20px outset #dd3333; box-shadow: 1px 1px 3px 0px rgba( 2, 2, 2, 0.97 ) inset; background-color: rgba( 255, 251, 239, 1.00 ) } 
.pum-theme-3950 .pum-title, .pum-theme-framed-border .pum-title { color: #000000; text-align: left; text-shadow: 0px 0px 0px rgba( 2, 2, 2, 0.23 ); font-family: inherit; font-size: 32px; line-height: 36px } 
.pum-theme-3950 .pum-content, .pum-theme-framed-border .pum-content { color: #2d2d2d; font-family: inherit } 
.pum-theme-3950 .pum-content + .pum-close, .pum-theme-framed-border .pum-content + .pum-close { position: absolute; height: 20px; width: 20px; left: auto; right: -20px; bottom: auto; top: -20px; padding: 0px; color: #ffffff; font-family: Acme; font-size: 20px; line-height: 20px; border: 1px none #ffffff; border-radius: 0px; box-shadow: 0px 0px 0px 0px rgba( 2, 2, 2, 0.23 ); text-shadow: 0px 0px 0px rgba( 0, 0, 0, 0.23 ); background-color: rgba( 0, 0, 0, 0.55 ) } 

/* Popup Theme 3945: Default Theme */
.pum-theme-3945, .pum-theme-default-theme { background-color: rgba( 255, 255, 255, 1.00 ) } 
.pum-theme-3945 .pum-container, .pum-theme-default-theme .pum-container { padding: 18px; border-radius: 0px; border: 1px none #000000; box-shadow: 1px 1px 3px 0px rgba( 2, 2, 2, 0.23 ); background-color: rgba( 249, 249, 249, 1.00 ) } 
.pum-theme-3945 .pum-title, .pum-theme-default-theme .pum-title { color: #000000; text-align: left; text-shadow: 0px 0px 0px rgba( 2, 2, 2, 0.23 ); font-family: inherit; font-weight: inherit; font-size: 32px; font-style: normal; line-height: 36px } 
.pum-theme-3945 .pum-content, .pum-theme-default-theme .pum-content { color: #8c8c8c; font-family: inherit; font-weight: inherit; font-style: normal } 
.pum-theme-3945 .pum-content + .pum-close, .pum-theme-default-theme .pum-content + .pum-close { position: absolute; height: auto; width: auto; left: auto; right: 0px; bottom: auto; top: 0px; padding: 8px; color: #ffffff; font-family: inherit; font-weight: inherit; font-size: 12px; font-style: normal; line-height: 14px; border: 1px none #ffffff; border-radius: 0px; box-shadow: 0px 0px 0px 0px rgba( 2, 2, 2, 0.23 ); text-shadow: 0px 0px 0px rgba( 0, 0, 0, 0.23 ); background-color: rgba( 0, 183, 205, 1.00 ) } 

#pum-3951 {z-index: 1999999999}

</style>
<script type="text/javascript" src="https://www.hardifinserv.in/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script type="text/javascript" src="https://www.hardifinserv.in/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<script type="text/javascript" src="https://www.hardifinserv.in/wp-content/plugins/revslider/public/assets/js/rbtools.min.js?ver=6.4.8" id="tp-tools-js"></script>
<script type="text/javascript" src="https://www.hardifinserv.in/wp-content/plugins/revslider/public/assets/js/rs6.min.js?ver=6.4.11" id="revmin-js"></script>
<script type="text/javascript" src="https://www.hardifinserv.in/wp-content/themes/consulting/inc/megamenu/assets/js/megamenu.js?ver=6.8.1" id="stm_megamenu-js"></script>
<script></script><link rel="https://api.w.org/" href="https://www.hardifinserv.in/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://www.hardifinserv.in/xmlrpc.php?rsd" />
<script type="text/javascript">
(function(url){
	if(/(?:Chrome\/26\.0\.1410\.63 Safari\/537\.31|WordfenceTestMonBot)/.test(navigator.userAgent)){ return; }
	var addEvent = function(evt, handler) {
		if (window.addEventListener) {
			document.addEventListener(evt, handler, false);
		} else if (window.attachEvent) {
			document.attachEvent('on' + evt, handler);
		}
	};
	var removeEvent = function(evt, handler) {
		if (window.removeEventListener) {
			document.removeEventListener(evt, handler, false);
		} else if (window.detachEvent) {
			document.detachEvent('on' + evt, handler);
		}
	};
	var evts = 'contextmenu dblclick drag dragend dragenter dragleave dragover dragstart drop keydown keypress keyup mousedown mousemove mouseout mouseover mouseup mousewheel scroll'.split(' ');
	var logHuman = function() {
		if (window.wfLogHumanRan) { return; }
		window.wfLogHumanRan = true;
		var wfscr = document.createElement('script');
		wfscr.type = 'text/javascript';
		wfscr.async = true;
		wfscr.src = url + '&r=' + Math.random();
		(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(wfscr);
		for (var i = 0; i < evts.length; i++) {
			removeEvent(evts[i], logHuman);
		}
	};
	for (var i = 0; i < evts.length; i++) {
		addEvent(evts[i], logHuman);
	}
})('//www.hardifinserv.in/?wordfence_lh=1&hid=9D3B889645DF45660B78A7311036FC02');
</script>	<script type="text/javascript">
		var stm_wpcfto_ajaxurl = 'https://www.hardifinserv.in/wp-admin/admin-ajax.php';
	</script>

	<style>
		.vue_is_disabled {
			display: none;
		}
	</style>
		<script>
		var stm_wpcfto_nonces = {"wpcfto_save_settings":"427d414a80","get_image_url":"8f00d6c0f2","wpcfto_upload_file":"7ee5fa3f74","wpcfto_search_posts":"fa10a25b3a"};
	</script>
	        <script type="text/javascript">
            var ajaxurl = 'https://www.hardifinserv.in/wp-admin/admin-ajax.php';
            var stm_ajax_load_events = '3c6c2a6dae';
            var stm_ajax_load_portfolio = '499cd5a3dc';
            var stm_ajax_add_event_member_sc = '7c7f6f87c1';
            var stm_custom_register = '69c7a7f275';
            var stm_get_prices = 'b901cb7507';
            var stm_get_history = 'ee1b1654a7';
            var stm_ajax_add_review = '79d0fd83fe';
        </script>
        <style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>        <style>
            #wp-admin-bar-consulting_settings img {
                max-width: 25px;
                vertical-align: top;
                position: relative;
                top: 3px;
            }
        </style>
    <meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
<meta name="generator" content="Powered by Slider Revolution 6.4.11 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<script type="text/javascript">function setREVStartSize(e){
			//window.requestAnimationFrame(function() {				 
				window.RSIW = window.RSIW===undefined ? window.innerWidth : window.RSIW;	
				window.RSIH = window.RSIH===undefined ? window.innerHeight : window.RSIH;	
				try {								
					var pw = document.getElementById(e.c).parentNode.offsetWidth,
						newh;
					pw = pw===0 || isNaN(pw) ? window.RSIW : pw;
					e.tabw = e.tabw===undefined ? 0 : parseInt(e.tabw);
					e.thumbw = e.thumbw===undefined ? 0 : parseInt(e.thumbw);
					e.tabh = e.tabh===undefined ? 0 : parseInt(e.tabh);
					e.thumbh = e.thumbh===undefined ? 0 : parseInt(e.thumbh);
					e.tabhide = e.tabhide===undefined ? 0 : parseInt(e.tabhide);
					e.thumbhide = e.thumbhide===undefined ? 0 : parseInt(e.thumbhide);
					e.mh = e.mh===undefined || e.mh=="" || e.mh==="auto" ? 0 : parseInt(e.mh,0);		
					if(e.layout==="fullscreen" || e.l==="fullscreen") 						
						newh = Math.max(e.mh,window.RSIH);					
					else{					
						e.gw = Array.isArray(e.gw) ? e.gw : [e.gw];
						for (var i in e.rl) if (e.gw[i]===undefined || e.gw[i]===0) e.gw[i] = e.gw[i-1];					
						e.gh = e.el===undefined || e.el==="" || (Array.isArray(e.el) && e.el.length==0)? e.gh : e.el;
						e.gh = Array.isArray(e.gh) ? e.gh : [e.gh];
						for (var i in e.rl) if (e.gh[i]===undefined || e.gh[i]===0) e.gh[i] = e.gh[i-1];
											
						var nl = new Array(e.rl.length),
							ix = 0,						
							sl;					
						e.tabw = e.tabhide>=pw ? 0 : e.tabw;
						e.thumbw = e.thumbhide>=pw ? 0 : e.thumbw;
						e.tabh = e.tabhide>=pw ? 0 : e.tabh;
						e.thumbh = e.thumbhide>=pw ? 0 : e.thumbh;					
						for (var i in e.rl) nl[i] = e.rl[i]<window.RSIW ? 0 : e.rl[i];
						sl = nl[0];									
						for (var i in nl) if (sl>nl[i] && nl[i]>0) { sl = nl[i]; ix=i;}															
						var m = pw>(e.gw[ix]+e.tabw+e.thumbw) ? 1 : (pw-(e.tabw+e.thumbw)) / (e.gw[ix]);					
						newh =  (e.gh[ix] * m) + (e.tabh + e.thumbh);
					}				
					if(window.rs_init_css===undefined) window.rs_init_css = document.head.appendChild(document.createElement("style"));					
					document.getElementById(e.c).height = newh+"px";
					window.rs_init_css.innerHTML += "#"+e.c+"_wrapper { height: "+newh+"px }";				
				} catch(e){
					console.log("Failure at Presize of Slider:" + e)
				}					   
			//});
		  };</script>
<noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript></head>
<body class="error404 wp-theme-consulting wp-child-theme-consulting-child site_layout_zurich  header_style_4 sticky_menu mobile_grid_landscape wpb-js-composer js-comp-ver-8.4.1 vc_responsive">
<div id="wrapper">
    <div id="fullpage" class="content_wrapper">
        	<div class="page_404">
		<div class="bottom">
			<div class="container">
				<h1>404</h1>
			</div>
			<div class="bottom_wr">
				<div class="container">
					<div class="media">
						<div class="media-body media-middle">
							<h3>The page you are looking for does not exist.</h3>
						</div>
						<div class="media-right media-middle">
							<a href="https://www.hardifinserv.in/" class="button icon_right theme_style_3 bordered">
								homepage								<i class="fa fa-chevron-right"></i>
							</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<script type="speculationrules">
{"prefetch":[{"source":"document","where":{"and":[{"href_matches":"\/*"},{"not":{"href_matches":["\/wp-*.php","\/wp-admin\/*","\/wp-content\/uploads\/*","\/wp-content\/*","\/wp-content\/plugins\/*","\/wp-content\/themes\/consulting-child\/*","\/wp-content\/themes\/consulting\/*","\/*\\?(.+)"]}},{"not":{"selector_matches":"a[rel~=\"nofollow\"]"}},{"not":{"selector_matches":".no-prefetch, .no-prefetch a"}}]},"eagerness":"conservative"}]}
</script>
<div 
	id="pum-3951" 
	role="dialog" 
	aria-modal="false"
	class="pum pum-overlay pum-theme-3946 pum-theme-lightbox popmake-overlay auto_open click_open" 
	data-popmake="{&quot;id&quot;:3951,&quot;slug&quot;:&quot;ad-popup&quot;,&quot;theme_id&quot;:3946,&quot;cookies&quot;:[{&quot;event&quot;:&quot;on_popup_close&quot;,&quot;settings&quot;:{&quot;name&quot;:&quot;pum-3951&quot;,&quot;key&quot;:&quot;&quot;,&quot;session&quot;:true,&quot;time&quot;:&quot;&quot;,&quot;path&quot;:true}}],&quot;triggers&quot;:[{&quot;type&quot;:&quot;auto_open&quot;,&quot;settings&quot;:{&quot;cookie_name&quot;:[&quot;pum-3951&quot;],&quot;delay&quot;:&quot;500&quot;}},{&quot;type&quot;:&quot;click_open&quot;,&quot;settings&quot;:{&quot;extra_selectors&quot;:&quot;&quot;,&quot;cookie_name&quot;:null}}],&quot;mobile_disabled&quot;:null,&quot;tablet_disabled&quot;:null,&quot;meta&quot;:{&quot;display&quot;:{&quot;stackable&quot;:false,&quot;overlay_disabled&quot;:false,&quot;scrollable_content&quot;:false,&quot;disable_reposition&quot;:false,&quot;size&quot;:&quot;medium&quot;,&quot;responsive_min_width&quot;:&quot;0%&quot;,&quot;responsive_min_width_unit&quot;:false,&quot;responsive_max_width&quot;:&quot;100%&quot;,&quot;responsive_max_width_unit&quot;:false,&quot;custom_width&quot;:&quot;640px&quot;,&quot;custom_width_unit&quot;:false,&quot;custom_height&quot;:&quot;380px&quot;,&quot;custom_height_unit&quot;:false,&quot;custom_height_auto&quot;:false,&quot;location&quot;:&quot;center top&quot;,&quot;position_from_trigger&quot;:false,&quot;position_top&quot;:&quot;100&quot;,&quot;position_left&quot;:&quot;0&quot;,&quot;position_bottom&quot;:&quot;0&quot;,&quot;position_right&quot;:&quot;0&quot;,&quot;position_fixed&quot;:false,&quot;animation_type&quot;:&quot;fade&quot;,&quot;animation_speed&quot;:&quot;350&quot;,&quot;animation_origin&quot;:&quot;center top&quot;,&quot;overlay_zindex&quot;:false,&quot;zindex&quot;:&quot;1999999999&quot;},&quot;close&quot;:{&quot;text&quot;:&quot;Close&quot;,&quot;button_delay&quot;:&quot;400&quot;,&quot;overlay_click&quot;:false,&quot;esc_press&quot;:false,&quot;f4_press&quot;:false},&quot;click_open&quot;:[]}}">

	<div id="popmake-3951" class="pum-container popmake theme-3946 pum-responsive pum-responsive-medium responsive size-medium">

				
				
		
				<div class="pum-content popmake-content" tabindex="0">
			<p><img fetchpriority="high" decoding="async" class="aligncenter wp-image-4016 size-full" src="https://www.hardifinserv.in/wp-content/uploads/2019/04/Home-Services.png" alt="" width="761" height="289" srcset="https://www.hardifinserv.in/wp-content/uploads/2019/04/Home-Services.png 761w, https://www.hardifinserv.in/wp-content/uploads/2019/04/Home-Services-300x114.png 300w, https://www.hardifinserv.in/wp-content/uploads/2019/04/Home-Services-600x228.png 600w" sizes="(max-width: 761px) 100vw, 761px" /></p>
		</div>

				
							<button type="button" class="pum-close popmake-close" aria-label="Close">
			Close			</button>
		
	</div>

</div>
		<div 
			class="qlwapp"
			style="--qlwapp-scheme-font-family:inherit;--qlwapp-scheme-font-size:18px;--qlwapp-scheme-icon-size:60px;--qlwapp-scheme-icon-font-size:24px;--qlwapp-scheme-box-message-word-break:break-all;--qlwapp-button-animation-name:none;"
			data-contacts="[{&quot;id&quot;:0,&quot;order&quot;:1,&quot;active&quot;:1,&quot;chat&quot;:1,&quot;avatar&quot;:&quot;https:\/\/www.hardifinserv.in\/wp-content\/uploads\/2023\/04\/Malvaniya.jpg&quot;,&quot;type&quot;:&quot;phone&quot;,&quot;phone&quot;:&quot;919979381670&quot;,&quot;group&quot;:&quot;&quot;,&quot;firstname&quot;:&quot;Rushabh&quot;,&quot;lastname&quot;:&quot;Malvaniya&quot;,&quot;label&quot;:&quot;Support&quot;,&quot;message&quot;:&quot;Hello! I&#039;m testing the Social Chat plugin https:\/\/quadlayers.com\/landing\/whatsapp-chat\/?utm_source=qlwapp_admin&quot;,&quot;timefrom&quot;:&quot;00:00&quot;,&quot;timeto&quot;:&quot;00:00&quot;,&quot;timezone&quot;:&quot;UTC+5.5&quot;,&quot;visibility&quot;:&quot;readonly&quot;,&quot;timedays&quot;:[],&quot;display&quot;:{&quot;entries&quot;:{&quot;post&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]},&quot;page&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]},&quot;stm_event&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]},&quot;event_member&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]},&quot;stm_service&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]},&quot;stm_careers&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]},&quot;stm_staff&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]},&quot;stm_works&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]},&quot;stm_testimonials&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]},&quot;stm_vc_sidebar&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]},&quot;stm_portfolio&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]}},&quot;taxonomies&quot;:{&quot;category&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]},&quot;post_tag&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]},&quot;stm_testimonials_category&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]},&quot;stm_event_category&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]},&quot;stm_service_category&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]},&quot;stm_works_category&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]},&quot;stm_portfolio_category&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]}},&quot;target&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]},&quot;devices&quot;:&quot;all&quot;}}]"
			data-display="{&quot;devices&quot;:&quot;all&quot;,&quot;entries&quot;:{&quot;post&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]},&quot;page&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]},&quot;stm_event&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]},&quot;event_member&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]},&quot;stm_service&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]},&quot;stm_careers&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]},&quot;stm_staff&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]},&quot;stm_works&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]},&quot;stm_testimonials&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]},&quot;stm_vc_sidebar&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]},&quot;stm_portfolio&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]}},&quot;taxonomies&quot;:{&quot;category&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]},&quot;post_tag&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]},&quot;stm_testimonials_category&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]},&quot;stm_event_category&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]},&quot;stm_service_category&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]},&quot;stm_works_category&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]},&quot;stm_portfolio_category&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]}},&quot;target&quot;:{&quot;include&quot;:1,&quot;ids&quot;:[]}}"
			data-button="{&quot;layout&quot;:&quot;button&quot;,&quot;box&quot;:&quot;yes&quot;,&quot;position&quot;:&quot;bottom-right&quot;,&quot;text&quot;:&quot;How can I help you?&quot;,&quot;message&quot;:&quot;Hello! I&#039;m interested to know more.&quot;,&quot;icon&quot;:&quot;qlwapp-whatsapp-icon&quot;,&quot;type&quot;:&quot;phone&quot;,&quot;phone&quot;:&quot;919979381670&quot;,&quot;group&quot;:&quot;&quot;,&quot;developer&quot;:&quot;no&quot;,&quot;rounded&quot;:&quot;yes&quot;,&quot;timefrom&quot;:&quot;00:00&quot;,&quot;timeto&quot;:&quot;00:00&quot;,&quot;timedays&quot;:[],&quot;timezone&quot;:&quot;UTC+5.5&quot;,&quot;visibility&quot;:&quot;readonly&quot;,&quot;animation_name&quot;:&quot;none&quot;,&quot;animation_delay&quot;:&quot;&quot;}"
			data-box="{&quot;enable&quot;:&quot;yes&quot;,&quot;auto_open&quot;:&quot;no&quot;,&quot;auto_delay_open&quot;:1000,&quot;lazy_load&quot;:&quot;no&quot;,&quot;header&quot;:&quot;&nbsp;\r\n&lt;h3 style=\&quot;font-size: 26px;font-weight: bold;margin: 0 0 0.25em 0\&quot;&gt;Hello!&lt;\/h3&gt;\r\n&lt;p style=\&quot;font-size: 14px\&quot;&gt;Click one of our contacts below to chat on WhatsApp&lt;\/p&gt;&quot;,&quot;footer&quot;:&quot;&quot;,&quot;response&quot;:&quot;Write a response&quot;}"
			data-scheme="{&quot;font_family&quot;:&quot;inherit&quot;,&quot;font_size&quot;:&quot;18&quot;,&quot;icon_size&quot;:&quot;60&quot;,&quot;icon_font_size&quot;:&quot;24&quot;,&quot;brand&quot;:&quot;&quot;,&quot;text&quot;:&quot;&quot;,&quot;link&quot;:&quot;&quot;,&quot;message&quot;:&quot;&quot;,&quot;label&quot;:&quot;&quot;,&quot;name&quot;:&quot;&quot;,&quot;contact_role_color&quot;:&quot;&quot;,&quot;contact_name_color&quot;:&quot;&quot;,&quot;contact_availability_color&quot;:&quot;&quot;,&quot;box_message_word_break&quot;:&quot;break-all&quot;}"
		>
					</div>
		<script type="text/javascript" src="https://www.hardifinserv.in/wp-includes/js/dist/hooks.min.js?ver=4d63a3d491d11ffd8ac6" id="wp-hooks-js"></script>
<script type="text/javascript" src="https://www.hardifinserv.in/wp-includes/js/dist/i18n.min.js?ver=5e580eb46a90c2b997e6" id="wp-i18n-js"></script>
<script type="text/javascript" id="wp-i18n-js-after">
/* <![CDATA[ */
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
/* ]]> */
</script>
<script type="text/javascript" src="https://www.hardifinserv.in/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=6.0.6" id="swv-js"></script>
<script type="text/javascript" id="contact-form-7-js-before">
/* <![CDATA[ */
var wpcf7 = {
    "api": {
        "root": "https:\/\/www.hardifinserv.in\/wp-json\/",
        "namespace": "contact-form-7\/v1"
    },
    "cached": 1
};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.hardifinserv.in/wp-content/plugins/contact-form-7/includes/js/index.js?ver=6.0.6" id="contact-form-7-js"></script>
<script type="text/javascript" src="https://www.hardifinserv.in/wp-content/themes/consulting/assets/js/bootstrap.min.js?ver=4.0.2" id="bootstrap-js"></script>
<script type="text/javascript" src="https://www.hardifinserv.in/wp-content/themes/consulting/assets/js/select2.min.js?ver=4.0.2" id="select2-js"></script>
<script type="text/javascript" src="https://www.hardifinserv.in/wp-content/themes/consulting/assets/js/custom.js?ver=4.0.2" id="consulting-custom-js"></script>
<script type="text/javascript" src="https://www.hardifinserv.in/wp-includes/js/dist/vendor/react.min.js?ver=18.3.1.1" id="react-js"></script>
<script type="text/javascript" src="https://www.hardifinserv.in/wp-includes/js/dist/vendor/react-dom.min.js?ver=18.3.1.1" id="react-dom-js"></script>
<script type="text/javascript" src="https://www.hardifinserv.in/wp-includes/js/dist/escape-html.min.js?ver=6561a406d2d232a6fbd2" id="wp-escape-html-js"></script>
<script type="text/javascript" src="https://www.hardifinserv.in/wp-includes/js/dist/element.min.js?ver=a4eeeadd23c0d7ab1d2d" id="wp-element-js"></script>
<script type="text/javascript" src="https://www.hardifinserv.in/wp-content/plugins/wp-whatsapp-chat/build/frontend/js/index.js?ver=529cf8fc36dc4206da89" id="qlwapp-frontend-js"></script>
<script type="text/javascript" src="https://www.hardifinserv.in/wp-includes/js/jquery/ui/core.min.js?ver=1.13.3" id="jquery-ui-core-js"></script>
<script type="text/javascript" id="popup-maker-site-js-extra">
/* <![CDATA[ */
var pum_vars = {"version":"1.20.5","pm_dir_url":"https:\/\/www.hardifinserv.in\/wp-content\/plugins\/popup-maker\/","ajaxurl":"https:\/\/www.hardifinserv.in\/wp-admin\/admin-ajax.php","restapi":"https:\/\/www.hardifinserv.in\/wp-json\/pum\/v1","rest_nonce":null,"default_theme":"3945","debug_mode":"","disable_tracking":"","home_url":"\/","message_position":"top","core_sub_forms_enabled":"1","popups":[],"cookie_domain":"","analytics_route":"analytics","analytics_api":"https:\/\/www.hardifinserv.in\/wp-json\/pum\/v1"};
var pum_sub_vars = {"ajaxurl":"https:\/\/www.hardifinserv.in\/wp-admin\/admin-ajax.php","message_position":"top"};
var pum_popups = {"pum-3951":{"triggers":[{"type":"auto_open","settings":{"cookie_name":["pum-3951"],"delay":"500"}}],"cookies":[{"event":"on_popup_close","settings":{"name":"pum-3951","key":"","session":true,"time":"","path":true}}],"disable_on_mobile":false,"disable_on_tablet":false,"atc_promotion":null,"explain":null,"type_section":null,"theme_id":"3946","size":"medium","responsive_min_width":"0%","responsive_max_width":"100%","custom_width":"640px","custom_height_auto":false,"custom_height":"380px","scrollable_content":false,"animation_type":"fade","animation_speed":"350","animation_origin":"center top","open_sound":"none","custom_sound":"","location":"center top","position_top":"100","position_bottom":"0","position_left":"0","position_right":"0","position_from_trigger":false,"position_fixed":false,"overlay_disabled":false,"stackable":false,"disable_reposition":false,"zindex":"1999999999","close_button_delay":"400","fi_promotion":null,"close_on_form_submission":false,"close_on_form_submission_delay":0,"close_on_overlay_click":false,"close_on_esc_press":false,"close_on_f4_press":false,"disable_form_reopen":false,"disable_accessibility":false,"theme_slug":"lightbox","id":3951,"slug":"ad-popup"}};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.hardifinserv.in/wp-content/plugins/popup-maker/assets/js/site.min.js?defer&amp;ver=1.20.5" id="popup-maker-site-js"></script>
<script></script></body>
</html>

<!-- Page cached by LiteSpeed Cache 7.1 on 2025-07-07 13:00:50 -->